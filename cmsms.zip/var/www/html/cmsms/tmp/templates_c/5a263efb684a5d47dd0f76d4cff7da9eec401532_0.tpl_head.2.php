<?php
/* Smarty version 4.5.2, created on 2025-05-26 22:51:30
  from 'tpl_head:2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834d452b34108_36005386',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5a263efb684a5d47dd0f76d4cff7da9eec401532' => 
    array (
      0 => 'tpl_head:2',
      1 => '1748288844',
      2 => 'tpl_head',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834d452b34108_36005386 (Smarty_Internal_Template $_smarty_tpl) {
}
}
