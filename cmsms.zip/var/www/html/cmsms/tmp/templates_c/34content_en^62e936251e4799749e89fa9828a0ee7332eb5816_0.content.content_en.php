<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:35:19
  from 'content:content_en' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834eca75da389_17694323',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '62e936251e4799749e89fa9828a0ee7332eb5816' => 
    array (
      0 => 'content:content_en',
      1 => 1748298898,
      2 => 'content',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834eca75da389_17694323 (Smarty_Internal_Template $_smarty_tpl) {
?><p>Cennik usług</p>
<p>Zapraszamy do zapoznania się z naszą ofertą oraz aktualnym cennikiem usług związanych z organizacją i planowaniem podr&oacute;ży.</p>
<p>Konsultacja podr&oacute;żnicza &mdash; 150 zł za godzinę<br /> Indywidualne doradztwo i pomoc w planowaniu wyjazdu.<br />Kompleksowy plan podr&oacute;ży &mdash; od 500 zł<br /> Szczeg&oacute;łowy plan wycieczki z rekomendacjami atrakcji, nocleg&oacute;w i transportu.<br />Rezerwacja nocleg&oacute;w &mdash; od 100 zł<br /> Pomoc w znalezieniu i rezerwacji hoteli lub apartament&oacute;w.<br />Organizacja wycieczek tematycznych &mdash; od 800 zł<br /> Specjalistyczne wycieczki, np. kulinarne, historyczne.<br />Transport i transfery &mdash; wycena indywidualna<br /> Organizacja przejazd&oacute;w lokalnych i międzynarodowych.<br />Ubezpieczenie podr&oacute;żne &mdash; od 50 zł<br /> Kompleksowe polisy dostosowane do celu podr&oacute;ży.<br /> <br />Warunki:</p>
<p>Ceny są orientacyjne i mogą się zmieniać w zależności od sezonu i indywidualnych wymagań. Wszystkie usługi dostosowujemy do potrzeb klienta.</p>
<p>Zapraszamy do kontaktu, chętnie przygotujemy ofertę skrojoną na miarę!</p><?php }
}
