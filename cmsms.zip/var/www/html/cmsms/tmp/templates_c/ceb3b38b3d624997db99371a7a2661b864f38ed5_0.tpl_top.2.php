<?php
/* Smarty version 4.5.2, created on 2025-05-26 22:51:30
  from 'tpl_top:2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834d452a82db1_86444086',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ceb3b38b3d624997db99371a7a2661b864f38ed5' => 
    array (
      0 => 'tpl_top:2',
      1 => '1748288844',
      2 => 'tpl_top',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834d452a82db1_86444086 (Smarty_Internal_Template $_smarty_tpl) {
}
}
