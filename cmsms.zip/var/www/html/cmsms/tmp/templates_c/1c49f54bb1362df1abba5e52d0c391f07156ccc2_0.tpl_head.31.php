<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:25:51
  from 'tpl_head:31' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834ea6f4c5167_90526712',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c49f54bb1362df1abba5e52d0c391f07156ccc2' => 
    array (
      0 => 'tpl_head:31',
      1 => '1748298334',
      2 => 'tpl_head',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834ea6f4c5167_90526712 (Smarty_Internal_Template $_smarty_tpl) {
}
}
