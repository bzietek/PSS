<?php
/* Smarty version 4.5.2, created on 2025-05-26 23:23:26
  from 'cms_stylesheet:Simplex Print' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834dbce057a05_56874144',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '08faf39047ec0274b7cbc67397724bc1dc380060' => 
    array (
      0 => 'cms_stylesheet:Simplex Print',
      1 => '1748278048',
      2 => 'cms_stylesheet',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834dbce057a05_56874144 (Smarty_Internal_Template $_smarty_tpl) {
?>/* cmsms stylesheet: Simplex Print modified: 05/26/25 23:23:26 */
body {background: #fff;color: #000;font-family: Georgia, Times New Roman, serif;font-size: 12pt}.noprint,.visuallyhidden {display: none}img {display: block;float: none}a:link:after {content: " (" attr(href) ") ";}a {text-decoration: underline}
<?php }
}
