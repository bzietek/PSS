<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:35:16
  from 'content:pagedata' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834eca43d1994_90656906',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f48edbbc04bfde01cbdbfa3ef9dec7c23ab66d68' => 
    array (
      0 => 'content:pagedata',
      1 => 1748298913,
      2 => 'content',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834eca43d1994_90656906 (Smarty_Internal_Template $_smarty_tpl) {
}
}
