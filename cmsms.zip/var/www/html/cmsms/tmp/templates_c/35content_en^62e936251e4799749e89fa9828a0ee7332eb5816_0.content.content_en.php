<?php
/* Smarty version 4.5.2, created on 2025-05-27 01:07:19
  from 'content:content_en' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834f4270bdae2_91779060',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '62e936251e4799749e89fa9828a0ee7332eb5816' => 
    array (
      0 => 'content:content_en',
      1 => 1748300837,
      2 => 'content',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834f4270bdae2_91779060 (Smarty_Internal_Template $_smarty_tpl) {
?><p><?php echo News::function_plugin(array('number'=>"5"),$_smarty_tpl);?>
</p><?php }
}
