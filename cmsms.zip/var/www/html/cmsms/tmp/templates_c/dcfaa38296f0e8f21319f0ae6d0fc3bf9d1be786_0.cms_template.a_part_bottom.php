<?php
/* Smarty version 4.5.2, created on 2025-05-26 23:50:28
  from 'cms_template:a_part_bottom' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834e224521707_57373942',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dcfaa38296f0e8f21319f0ae6d0fc3bf9d1be786' => 
    array (
      0 => 'cms_template:a_part_bottom',
      1 => '1748295994',
      2 => 'cms_template',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834e224521707_57373942 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/cmsms/lib/plugins/function.sitename.php','function'=>'smarty_function_sitename',),));
?>
</section>

	<footer style="text-align:center; color:#666; font-size:0.9rem; margin:3rem 0 1rem 0;">
		<p>&copy; <?php echo '<?php'; ?>
 echo date("Y"); <?php echo '?>'; ?>
 <?php echo smarty_function_sitename(array(),$_smarty_tpl);?>
. Wszelkie prawa zastrzeżone.</p>
	</footer>
</body>
</html><?php }
}
