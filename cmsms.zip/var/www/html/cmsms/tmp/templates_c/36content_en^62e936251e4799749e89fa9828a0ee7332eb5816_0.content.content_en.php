<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:36:29
  from 'content:content_en' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834eced27b751_97749193',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '62e936251e4799749e89fa9828a0ee7332eb5816' => 
    array (
      0 => 'content:content_en',
      1 => 1748298986,
      2 => 'content',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834eced27b751_97749193 (Smarty_Internal_Template $_smarty_tpl) {
?><p><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['Gallery'][0], array( array('dir'=>'zdjecia/20250526wreczenie_dyplomow'),$_smarty_tpl ) );?>
</p><?php }
}
