<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:25:51
  from 'tpl_top:31' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834ea6f46fd23_81658199',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0be5b939b52772aef72083f864deb3b52e3b3bd2' => 
    array (
      0 => 'tpl_top:31',
      1 => '1748298334',
      2 => 'tpl_top',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834ea6f46fd23_81658199 (Smarty_Internal_Template $_smarty_tpl) {
}
}
