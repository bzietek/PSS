<?php
/* Smarty version 4.5.2, created on 2025-05-27 01:12:30
  from 'cms_template:notemplate' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834f55e4bed09_42876148',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '690d404c76251d1509568efadb399487d4882656' => 
    array (
      0 => 'cms_template:notemplate',
      1 => 1748301150,
      2 => 'cms_template',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834f55e4bed09_42876148 (Smarty_Internal_Template $_smarty_tpl) {
CMS_Content_Block::smarty_internal_fetch_contentblock(array(),$_smarty_tpl);
}
}
