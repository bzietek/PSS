<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:35:08
  from 'cms_template:31' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834ec9c6f0901_90802904',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '246ecabaee95a798d779b676af83057b2c1a2c6a' => 
    array (
      0 => 'cms_template:31',
      1 => '1748298334',
      2 => 'cms_template',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834ec9c6f0901_90802904 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/cmsms/lib/plugins/function.global_content.php','function'=>'smarty_function_global_content',),));
echo smarty_function_global_content(array('name'=>"a_part_top"),$_smarty_tpl);?>



	

<?php echo smarty_function_global_content(array('name'=>"a_part_bottom"),$_smarty_tpl);
}
}
