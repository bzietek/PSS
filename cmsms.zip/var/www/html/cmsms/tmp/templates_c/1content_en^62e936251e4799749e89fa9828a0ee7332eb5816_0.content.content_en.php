<?php
/* Smarty version 4.5.2, created on 2025-05-27 00:35:16
  from 'content:content_en' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.2',
  'unifunc' => 'content_6834eca440a047_60852970',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '62e936251e4799749e89fa9828a0ee7332eb5816' => 
    array (
      0 => 'content:content_en',
      1 => 1748298913,
      2 => 'content',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6834eca440a047_60852970 (Smarty_Internal_Template $_smarty_tpl) {
?><p>Witaj na naszej stronie podr&oacute;żniczej!<br />Cieszymy się, że tu jesteś! Nasza strona to miejsce stworzone z pasji do odkrywania świata, poznawania nowych kultur i dzielenia się inspiracjami podr&oacute;żniczymi. Niezależnie od tego, czy planujesz pierwszą wyprawę, czy jesteś doświadczonym globtroterem, znajdziesz tu praktyczne porady, ciekawe artykuły oraz najświeższe informacje o najpiękniejszych zakątkach naszej planety.</p>
<p>Zapraszamy do zwiedzania, marzeń i planowania kolejnych podr&oacute;ży razem z nami!</p><?php }
}
